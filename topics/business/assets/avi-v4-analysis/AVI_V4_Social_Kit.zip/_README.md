# AVI V4 社群發文素材包

產生日期：2026-04-20
版本：v2.0

## 包裝內容

### 0_OVERVIEW/
- `AVI_V4_Asset_Overview.png` — 14 張素材總覽縮圖
- `AVI_V4_Posting_Schedule.xlsx` — 發文行事曆（行事曆 + KPI 總覽兩個分頁）

### 1_DOCS/
- `AVI_V4_Introduction_Guide.md` — 完整技術指南（13 章節）
- `AVI_V4_Blog_Analysis.md` — 12 個月分析 + 五次崩盤 + 部落格文
- `AVI_V4_Social_Posts.md` — IG Carousel + Threads 10 則
- `AVI_V4_Social_Posts_v2.md` — 擴充 X/Twitter + IG Stories

### 2_BLOG_CHARTS/ — Blog 內嵌圖 (5)
### 3_RADAR_CHARTS/ — 雷達圖 3 變體
### 4_IG_STORIES/ — IG Stories 9:16 垂直 (4)
### 5_X_TWITTER/ — X/Twitter 16:9 橫向 (2)

## 總計：14 張素材圖 + 4 份文件 + 2 份 OVERVIEW

## 發文順序

參考 `0_OVERVIEW/AVI_V4_Posting_Schedule.xlsx`：
1. Day 1 週二 09:00 X Thread 開跑
2. Day 1 21:00 IG Carousel + Stories 連發
3. Day 1-2 Threads 拆 4 波
4. Day 6 週末整理 Medium 長文

## 關鍵訊息（不要弄錯）

- AVI V4 = 7.00（2026-04-20）
- 30 年來第 3 次破 7.0
- 前兩次：1999 / 2021
- 預估市場見頂：2027 Q1-Q2（基本情境 50%）

## 使用限制

本素材為個人分析，非投資建議。
